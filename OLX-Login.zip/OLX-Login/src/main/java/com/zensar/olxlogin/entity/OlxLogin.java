package com.zensar.olxlogin.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OlxLogin {

	private long id;
	private String FirstName;
	private String LastName;
	private String UserName;
	private String Password;
	private String Email;
	private long Phone;
	
	
}
